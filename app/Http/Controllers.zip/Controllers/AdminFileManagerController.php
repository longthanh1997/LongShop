<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminFileManagerController extends Controller
{
    public function showFileManager(){
    	return view('admin.filemanager');
    }
    public function postFileManager(){
    	$folder = array_filter(glob('public/upload/*'), 'is_dir');
    	$output = '<table class="table">
    		<tr>
    			<td>Link</td>
    			<td>Total file</td>
    			<td>update</td>
    			<td>delete</td>
    			<td>Upload file</td>
    			<td>View Upload file</td>
    		</tr>
    	';

    	if(count($folder) > 0){
    		foreach ($folder as $name) {
    			$output .= '<tr>
    				<td>'.$name.'</td>
    				<td>'.(count(scandir($name)) - 2).'</td>
    				<td><button data-name='.$name.' class="btn btn-primary">update</td>
    				<td><button data-name='.$name.' class="btn btn-danger">delete</td>
    				<td><button data-name='.$name.' class="btn btn-danger">Upload</td>
    				<td><button data-name='.$name.' class="btn btn-info">View</td>
    			</tr>';
    		}
    	}
    	else{
    		$output = '<tr>
    			<td colspan="6">No result</td>
    		</tr>';
    	}
    	return $output.'</table>';
    }
}
